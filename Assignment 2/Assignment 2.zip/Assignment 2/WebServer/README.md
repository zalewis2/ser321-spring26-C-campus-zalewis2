#### Purpose:
Create a simple webserver and a little fun Webserver. The server will run on the specified port. 

You can reach the website by going to localhost:PORT in your Browswer. PORT is the port that is specified in the Java file (default in 9000).

If you want you can of course make this an input and have Gradle set the value. 

Run through

gradle SimpleWebServer

OR 

gradle FunWebServer


The FunWebServer does a little more than the SimpleWebServer. Check out what it does :-)